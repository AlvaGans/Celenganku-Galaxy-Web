# Celenganku - Galaxy Web

Flask-based version of the Celenganku app with a galaxy theme.